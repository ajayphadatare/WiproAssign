# File name to check
file="maria.txt"
 
# Check if the file exists
if [ -e "$file" ]; then
  echo "File exists"
else
  echo "File not found"
fi 