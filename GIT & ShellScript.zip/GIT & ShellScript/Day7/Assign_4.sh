# Create a directory named TestDirOld
mkdir -p TestDirOld
 
# Change to the TestDirOld directory
cd TestDirOld
 
# Loop to create 10 files
for i in {1..10}; do
  filename="File$i.txt"
  echo "$filename" > "$filename"
done
 
echo "Files created successfully in TestDirOld."