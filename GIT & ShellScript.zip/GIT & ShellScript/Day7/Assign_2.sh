#!/bin/bash

while true; do
    read -p "Enter a number (enter '0' to stop): " number

    if ! [[ "$number" =~ ^-?[0-9]+$ ]]; then
        echo "Please enter a valid integer."
        continue
    fi

    if [ "$number" -eq 0 ]; then
        break
    elif [ $((number % 2)) -eq 0 ]; then
        echo "$number is even."
    else
        echo "$number is odd."
    fi
done
