package day4_basicexception;

import java.util.Scanner;

public class DivideByZero {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Numerator : ");
		int numerator = sc.nextInt();
		System.out.println("Enter Denometer : ");
		int denometer = sc.nextInt();
		try {
			int result = numerator/denometer;
			System.out.println("result : "+result);
			
		} catch (ArithmeticException e) {
			System.out.println("can not divide by zero!");
		}
	}

}
