import java.util.Random;
import java.util.Scanner;

public class Task7b_searching {
	
	public static int PerformLinearSearch(int[] arr, int target) {
		  for (int i = 0; i < arr.length; i++) {
		    if (arr[i] == target) {
		      return i;
		    }
		  }
		  return -1;
		}
	
	public static int[] InitializeArray(int n) {
		  
	    return new Random().ints(1, 101).limit(n).toArray();
	  }
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter size of an array : ");
		int n=sc.nextInt();
		System.out.println("Enter no to find : ");
		int num = sc.nextInt();
		
		int[] arr = InitializeArray(n);
		System.out.println("Array is : "+java.util.Arrays.toString(arr));
		System.out.println(PerformLinearSearch(arr, num));
		
	}

}