package Day4_task2_Inheritance;

public class shape {

	public double area() {
        return 0.0; 
    }
}
