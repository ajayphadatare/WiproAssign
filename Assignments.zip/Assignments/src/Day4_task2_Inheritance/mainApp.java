package Day4_task2_Inheritance;

import java.util.Scanner;

public class mainApp {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the choice : \n 1:circle \n 2: rectangle ");
		int choice = sc.nextInt();
		if (choice==1) {
			System.out.println("Enter the radius : ");
			int radius = sc.nextInt();
			Circle circle = new Circle(radius);
			System.out.println("Area of circle = "+circle.area());
		}
		else if (choice==2) {
			System.out.println("Enter the length : ");
			int length = sc.nextInt();
			System.out.println("Enter the width : ");
			int width = sc.nextInt();
			rectangle rec = new rectangle(length, width);
			System.out.println("Area of rectangle  = "+rec.area());
		}
		else {
			System.out.println("Invalid choice..");
		}
	}

}
