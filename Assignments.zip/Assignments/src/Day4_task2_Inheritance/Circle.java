package Day4_task2_Inheritance;

public class Circle extends shape {
	private double radius;
	
	 public Circle(double radius) {
	        this.radius = radius;
	    }
	
	public double area() {
		return Math.PI*radius*radius;
		
	}

}
