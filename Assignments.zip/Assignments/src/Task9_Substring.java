import java.util.Scanner;

public class Task9_Substring {

	    public static void main(String[] args) {
	    	Scanner sc = new Scanner(System.in);
	    	System.out.println("Enter string 1 : ");
	        String str1 =sc.nextLine();
	    	System.out.println("Enter string 2 : ");
	        String str2 = sc.nextLine();
	    	System.out.println("Enter substring length : ");
	        int substringLength =sc.nextInt();

	        String result = getMiddleSubstring(str1, str2, substringLength);
	        System.out.println("Middle substring: " + result);
	    }

	    public static String getMiddleSubstring(String str1, String str2, int length) {
	       
	        String concatenated = str1.concat(str2);

	        StringBuilder reversed = new StringBuilder(concatenated).reverse();

	        if (reversed.length() == 0 || length <= 0) {
	            return "";
	        }

	        length = Math.min(length, reversed.length());

	        int startIndex = (reversed.length() - length) / 2;

	        String middleSubstring = reversed.substring(startIndex, startIndex + length);

	        return middleSubstring;
	    }
}
