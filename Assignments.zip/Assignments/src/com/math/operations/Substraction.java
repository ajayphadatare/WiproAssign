package com.math.operations;

public class Substraction {
	
	public static int substraction(int a , int b) {
		
		return a-b;
	}

}
