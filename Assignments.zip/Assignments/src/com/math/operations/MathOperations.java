package com.math.operations;
import java.util.Scanner;
public class MathOperations {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter 1st no : ");
		int num1= sc.nextInt();
		System.out.println("Enter 2nd no : ");
		int num2= sc.nextInt();
		System.out.println("Enter choice : 1- sum \n 2-Substraction");
		int choice = sc.nextInt();
		if (choice==1) {
			int sum= Addition.add(num1, num2);
			System.out.println(sum);
		}
		else {
			int diff = Substraction.substraction(num1, num2);
			System.out.println(diff);
		}
		
	}

}
