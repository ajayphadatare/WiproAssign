import java.util.HashSet;

public class Task5_TwoSum {
	
	public static boolean hasTwoSum(int[] nums, int target) {
        HashSet<Integer> set = new HashSet<>();
        
        for (int num : nums) {
            int complement = target - num;
            if (set.contains(complement)) {
                return true;
            }
            set.add(num);
        }
        
        return false;
    }
    
    public static void main(String[] args) {
        int[] nums = {5,4,11,7};
        int target = 3;
        
        if (hasTwoSum(nums, target)) {
            System.out.println("Two numbers that add up to " + target + " exist.");
        } else {
            System.out.println("No two numbers add up to " + target + ".");
        }
    }
}
