import java.util.Random;

public class Task7a_ArraySorting {
	
	public static void main(String[] args) {
	    int[] arr = InitializeArray(10);
	    System.out.println("Original array: " + java.util.Arrays.toString(arr));
	    BruteForceSort(arr);
	    System.out.println("Sorted array: " + java.util.Arrays.toString(arr));
	  }

	public static int[] InitializeArray(int size) {
        if (size < 1) {
            throw new IllegalArgumentException("Array size must be at least 1");
        }
        int[] array = new int[size];
        for (int i = 0; i < size; i++) {
            array[i] = (int) (Math.random() * 100);
        }
        return array;
    }

	  public static void BruteForceSort(int[] arr) {
	 
	    for (int i = 0; i < arr.length - 1; i++) {
	      for (int j = i + 1; j < arr.length; j++) {
	        if (arr[i] > arr[j]) {
	          int temp = arr[i];
	          arr[i] = arr[j];
	          arr[j] = temp;
	        }
	      }
	    }
	  }

}
