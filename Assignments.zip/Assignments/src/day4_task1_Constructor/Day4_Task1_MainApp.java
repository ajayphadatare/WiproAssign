package day4_task1_Constructor;

public class Day4_Task1_MainApp {
	
	 public static void main(String[] args) {
		    // Create a 3x4 matrix
		    Matrix matrix = new Matrix(3, 4);

		    // Fill the matrix with 5
		    matrix.fillWithValues(5);

		    matrix.displayMatrix();
		  }

}
