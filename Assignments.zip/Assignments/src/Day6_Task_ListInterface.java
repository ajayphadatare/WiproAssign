import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Day6_Task_ListInterface {
	
	public static void main(String[] args) {
        List<Integer> List = new ArrayList<>(Arrays.asList(2,3,1,4,5,3,7,6,8,9,7,4,1,9));
        remove(List);
    }
	
	public static void remove(List<Integer> list) {
        Iterator<Integer> iterator = list.iterator();
        boolean remove = false;

        while (iterator.hasNext()) {
            iterator.next();
            if (remove) {
                iterator.remove();
            }
            remove = !remove;
        }

        System.out.println("After removing second element:");
        System.out.println(list);
    }
}
