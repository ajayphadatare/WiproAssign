
public class Task1_dataType {

	public static void main(String[] args) {

		int x = 10;
	    int y = 20;

	    System.out.println("Before swapping: x = " + x + ", y = " + y);

	    x = x + y;  // x becomes 30 (10 + 20)
	    y = x - y;  // y becomes 10 (30 - 20)
	    x = x - y;  // x becomes 20 (30 - 10)

	    System.out.println("After swapping: x = " + x + ", y = " + y);
	}

}
