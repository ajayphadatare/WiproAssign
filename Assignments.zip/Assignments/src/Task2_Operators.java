
public class Task2_Operators {

	public static void main(String[] args) {

		    double num1;
		    double num2;
		    char operator;

		    try {
		      num1 = Double.parseDouble(args[0]);
		      num2 = Double.parseDouble(args[1]);
		      operator = args[2].charAt(0);
		    } catch (NumberFormatException e) {
		      System.out.println("Error: Invalid input. Please enter numbers.");
		      return;
		    }

		    double result;
		    switch (operator) {
		      case '+':
		        result = num1 + num2;
		        break;
		      case '-':
		        result = num1 - num2;
		        break;
		      case '*':
		        result = num1 * num2;
		        break;
		      case '/':
		        if (num2 == 0) {
		          System.out.println("Error: Division by zero.");
		          return;
		        }
		        result = num1 / num2;
		        break;
		      default:
		        System.out.println("Error: Invalid operator. Supported operators: +, -, *, /");
		        return;
		    }

		    System.out.println("Result: " + num1 + " " + operator + " " + num2 + " = " + result);
		 
	}

}
