
public class Task8b_Recursive {
	
	 public static void main(String[] args) {
	        int n = 10; 

	        int[] fibArray = new int[n];

	        generateFibSeq(fibArray, n);

	        System.out.println("Fibonacci sequence of first " + n + " elements:");
	        for (int num : fibArray) {
	            System.out.print(num + " ");
	        }
	       
	        int nthElement = fibonacci(n);
	        System.out.println("The " + n + "th element of Fibonacci sequence is: " + nthElement);
	    }

	    public static int fibonacci(int n) {
	        if (n <= 1) {
	            return n;
	        }
	        return fibonacci(n - 1) + fibonacci(n - 2);
	    }

	    public static void generateFibSeq(int[] array, int n) {
	        for (int i = 0; i < n; i++) {
	            array[i] = fibonacci(i);
	        }
	    }

}
