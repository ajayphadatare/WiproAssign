
public class Task8a_Slice {
	
	    public static void main(String[] args) {
	 
	        int[] originalArray = {23,34,45,56,78,54,32,12};
	        int startIndex = 2;
	        int endIndex = 6;

	        int[] slicedArray = sliceArray(originalArray, startIndex, endIndex);

	        for (int num : slicedArray) {
	            System.out.print(num + " ");
	        }
	    }

	    public static int[] sliceArray(int[] arr, int start, int end) {
	    	
	        start = Math.max(0, start);
	        
	        end = Math.min(arr.length, end);

	        int newSize = end - start;
	        
	        int[] slicedArray = new int[newSize];

	        for (int i = start; i < end; i++) {
	            slicedArray[i - start] = arr[i];
	        }

	        return slicedArray;
	    }

}
