
public class Task6_FunThrArray {

		public static int sumArray(int[] arr, int n) {
		  
		    if (n == 0) {
		      return 0;
		    } else {
		      return arr[n - 1] + sumArray(arr, n - 1);
		    }
		  }

		  public static void main(String[] args) {
		    int[] myArr = {1, 2, 3, 4, 5};
		    int result = sumArray(myArr, myArr.length);
		    System.out.println("The sum of the elements in the array is: " + result);
		  }

}
